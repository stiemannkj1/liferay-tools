<#include "java_header.java">
public enum ${name} {

}
