<#include "java_header.java">
public class ${name} {

}
