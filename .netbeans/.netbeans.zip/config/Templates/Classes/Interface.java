<#include "java_header.java">
interface ${name} {

}
