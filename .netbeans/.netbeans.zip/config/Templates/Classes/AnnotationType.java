<#include "java_header.java">
public @interface ${name} {

}
